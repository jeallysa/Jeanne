/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bean;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Database {
    private Connection conn = null;
    
    public Database() throws SQLException{
       conn  = DriverManager.getConnection("jdbc:mysql://localhost/educationaldb", "root", "");
    }
    
    public ResultSet getProfileInfo(String id) throws SQLException{
       PreparedStatement ps = this.conn.prepareStatement("SELECT * FROM customer WHERE cuID=?");
       ps.setString(1, id);
       ResultSet result = ps.executeQuery();
       return result;
    }
}
