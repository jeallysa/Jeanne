/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package beans;

/**
 *
 * @author averey
 */
public class Service {

    private String s_id = "";
    private String s_name = "";
    private String s_category = "";
    private String s_price = "";
    private String spID = "";
    private String firstName = "";
    private String lastName = "";
    private String contact = "";
    
    public Service(String s_id, String s_name, String s_category, String s_price, String spID, String firstName, String lastName, String contact){
        this.s_id = s_id;
        this.s_name = s_name;
        this.s_category = s_category;
        this.s_price = s_price;
        this.spID = spID;
        this.firstName = firstName;
        this.lastName = lastName;
        this.contact = contact;
    }
    
    /**
     * @return the s_price
     */
    public String getS_price() {
        return s_price;
    }

    /**
     * @return the contact
     */
    public String getContact() {
        return contact;
    }
    
    /**
     * @return the s_id
     */
    public String getS_id() {
        return s_id;
    }

    /**
     * @return the s_name
     */
    public String getS_name() {
        return s_name;
    }

    /**
     * @return the s_category
     */
    public String getS_category() {
        return s_category;
    }

    /**
     * @return the spID
     */
    public String getSpID() {
        return spID;
    }

    /**
     * @return the firstName
     */
    public String getFirstName() {
        return firstName;
    }

    /**
     * @return the lastName
     */
    public String getLastName() {
        return lastName;
    }
    
    
    
}
