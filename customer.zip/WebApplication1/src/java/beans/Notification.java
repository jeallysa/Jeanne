/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package beans;

/**
 *
 * @author boni
 */
public class Notification {
    
    private int spID = 0;
    private int reqID = 0;
    private String firstName = "";
    private String lastName = "";
    private String contact = "";
    private String email = "";
    private String address = "";
    private String service = "";
    private String category = "";
    private String status = "";
    private String date = "";
    private String time = "";
    
    
    public Notification(int spID, int reqID, String firstName, String lastName, String contact, String email, String address, String service, String category, String status, String date, String time){
        this.spID = spID;
        this.reqID = reqID;
        this.firstName = firstName;
        this.lastName = lastName;
        this.contact = contact;
        this.email = email;
        this.address = address;
        this.service = service;
        this.category = category;
        this.status = status;
        this.date = date;
        this.time = time;
    }

    public int getSpID() {
        return spID;
    }

    public int getReqID() {
        return reqID;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getContact() {
        return contact;
    }

    public String getEmail() {
        return email;
    }

    public String getAddress() {
        return address;
    }

    public String getService() {
        return service;
    }

    public String getCategory() {
        return category;
    }

    public String getStatus() {
        return status;
    }

    public String getDate() {
        return date;
    }
    
    public String getTime() {
        return time;
    }
    
}
