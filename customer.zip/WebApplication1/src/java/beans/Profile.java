/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package beans;

/**
 *
 * @author boni
 */
public class Profile {

    private int id = 0;
    private String image = "";
    private String firstName = "";
    private String lastName = "";
    private String contact = "";
    private String username = "";
    private String password = "";
    private String email = "";
    private String address = "";
    private String bd_numeric = "";
    private String bd_string = "";
    
    public Profile(int cuID, String image, String firstName, String lastName, String contact, String username, String password, String email, String address, String bd_numeric, String bd_string){
        this.id = cuID;
        this.image = image;
        this.firstName = firstName;
        this.lastName = lastName;
        this.contact = contact;
        this.username = username;
        this.password = password;
        this.email = email;
        this.address = address;
        this.bd_numeric = bd_numeric;
        this.bd_string = bd_string;
    }
    
    public Profile(int cuID, String image, String firstName, String lastName, String contact, String email, String address, String username, String password){
        this.id = cuID;
        this.image = image;
        this.firstName = firstName;
        this.lastName = lastName;
        this.contact = contact;
        this.email = email;
        this.address = address;
        this.username = username;
        this.password = password;
    }
    
    public int getId() {
        return id;
    }
    
    public String getImage() {
        return image;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getContact() {
        return contact;
    }
    
    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    public String getEmail() {
        return email;
    }

    public String getAddress() {
        return address;
    }

    public String getBd_numeric() {
        return bd_numeric;
    }

    public String getBd_string() {
        return bd_string;
    }
 
}
