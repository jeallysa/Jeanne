/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package beans;

/**
 *
 * @author 
 */
import java.util.*;
import java.io.*;
import java.sql.*;

public class Database {
    String db_host = "";
    String db_name = "";
    String db_username = "";
    String db_password = "";
    
    Connection conn = null;
    
    public Database() throws IOException, SQLException{
        Properties config = new Properties();
        config.load(getClass().getResourceAsStream("../../configuration.ini"));

        this.db_name = config.getProperty("db_name").replace("\"", "");
        this.db_host = "jdbc:mysql://" + config.getProperty("db_host").replace("\"", "") + "/" + this.db_name;
        this.db_username = config.getProperty("db_username").replace("\"", "");
        this.db_password = config.getProperty("db_password").replace("\"", "");

        this.conn = DriverManager.getConnection(this.db_host, this.db_username, this.db_password);
    }
    
    public void addService(String cuID, String s_id, String date_needed) throws SQLException{
        PreparedStatement ps = this.conn.prepareStatement("INSERT INTO request(s_id, reqDate, status, last_updated, cuID, notification_customer) VALUES(?, ?, ?, ?, ?, ?)");

        ps.setInt(1, Integer.parseInt(s_id));
        ps.setString(2, date_needed);
        ps.setString(3, "pending");
        ps.setDate(4, java.sql.Date.valueOf(java.time.LocalDate.now()));
        ps.setString(5, cuID);
        ps.setString(6, "0");
        ps.executeUpdate();
    }
    
    public int cancelService(String reqID) throws SQLException{
        PreparedStatement ps = this.conn.prepareStatement("UPDATE request SET status = 'cancelled' WHERE reqID = ?");
        ps.setString(1, reqID);
        return ps.executeUpdate();
    }
    
    public ResultSet getAllMathRequest(String cuID) throws SQLException{
        PreparedStatement ps = this.conn.prepareStatement("SELECT s.*, sp.* FROM services s JOIN service_provider sp ON sp.spID = s.spID WHERE s.s_category = 'academics' AND s.flag = '1'");
        return ps.executeQuery();
    }
    
    public ResultSet getAllEnglishRequest(String cuID) throws SQLException{
        PreparedStatement ps = this.conn.prepareStatement("SELECT s.*, sp.* FROM services s JOIN service_provider sp ON sp.spID = s.spID WHERE s.s_category = 'instruments' AND s.flag = '1'");
        return ps.executeQuery();
    }
    
    public ResultSet getAllScienceRequest(String cuID) throws SQLException{
        PreparedStatement ps = this.conn.prepareStatement("SELECT s.*, sp.* FROM services s JOIN service_provider sp ON sp.spID = s.spID WHERE s.s_category = 'languages' AND s.flag = '1'");
        return ps.executeQuery();
    }
    
    public ResultSet getAllSocialStudiesRequest(String cuID) throws SQLException{
        PreparedStatement ps = this.conn.prepareStatement("SELECT s.*, sp.* FROM services s JOIN service_provider sp ON sp.spID = s.spID WHERE s.s_category = 'cb' AND s.flag = '1'");
        return ps.executeQuery();
    }
    
    public ResultSet getAllTransaction(String cuID) throws SQLException{
        PreparedStatement ps = this.conn.prepareStatement("SELECT r.*, s.*, sp.* FROM request r JOIN services s ON s.s_id = r.s_id JOIN service_provider sp ON sp.spID = s.spID WHERE r.status IN ('confirmed', 'declined') AND r.cuID = ?");
        ps.setString(1, cuID);
        return ps.executeQuery();
    }
    
    public ResultSet getAllRequest(String cuID) throws SQLException{
        PreparedStatement ps = this.conn.prepareStatement("SELECT s.*, r.*, sp.* FROM services s JOIN request r ON r.s_id = s.s_id JOIN service_provider sp ON sp.spID = s.spID WHERE r.status = 'pending' AND r.cuID = ?");
        ps.setString(1, cuID);
        return ps.executeQuery();
    }
    
    public ResultSet getNotification(String cuID) throws SQLException{
        PreparedStatement ps = this.conn.prepareStatement("SELECT r.*, s.*, sp.* FROM request r JOIN services s ON s.s_id = r.s_id JOIN service_provider sp ON sp.spID = s.spID WHERE r.status IN ('confirmed', 'declined') AND r.notification_customer = '1' AND r.cuID = ?");
        ps.setString(1, cuID);
        ResultSet result = ps.executeQuery();

        return result;
    }
    
    public ResultSet getNotificationTable(String cuID) throws SQLException{
        PreparedStatement ps = this.conn.prepareStatement("SELECT r.*, s.*, sp.* FROM request r JOIN services s ON s.s_id = r.s_id JOIN service_provider sp ON sp.spID = s.spID WHERE r.status IN ('confirmed', 'declined') AND r.notification_customer = '1' AND r.cuID = ?");
        ps.setString(1, cuID);
        ResultSet result = ps.executeQuery();
        
        PreparedStatement ps1 = this.conn.prepareStatement("UPDATE request SET notification_customer = '0' WHERE cuID = ?");
        ps1.setString(1, cuID);
        ps1.executeUpdate();
        return result;
    }
    
    public ResultSet getProfile(String cuID) throws SQLException{
        PreparedStatement ps = this.conn.prepareStatement("SELECT *, DATE_FORMAT(Birthdate, '%M %e, %Y') AS bd_string, Birthdate AS bd_numeric FROM customer WHERE cuID = ?");
        ps.setString(1, cuID);
        return ps.executeQuery();
    }
    
    public void editProfile(Profile profile) throws SQLException{
        PreparedStatement ps = this.conn.prepareStatement("UPDATE customer SET Image = ?, UserName = ?, FirstName = ?, LastName = ?, ContactNumber = ?, Password = ?, Email = ?, Address = ? WHERE cuID = ?");
        ps.setString(1, profile.getImage());
        ps.setString(2, profile.getUsername());
        ps.setString(3, profile.getFirstName());
        ps.setString(4, profile.getLastName());
        ps.setString(5, profile.getContact());
        ps.setString(6, profile.getPassword());
        ps.setString(7, profile.getEmail());
        ps.setString(8, profile.getAddress());
        ps.setInt(9, profile.getId());
        ps.executeUpdate();
    }
    
    public ResultSet acceptLogin(String cuID) throws SQLException{
        PreparedStatement ps = this.conn.prepareStatement("SELECT *, DATE_FORMAT(Birthdate, '%M %e, %Y') AS bd_string, Birthdate AS bd_numeric FROM customer WHERE cuID = ?");
        ps.setString(1, cuID);
        return ps.executeQuery();
    }
    
    public void updateNotification(String id) throws SQLException{
        PreparedStatement ps = this.conn.prepareStatement("UPDATE request r SET r.notification = '0'");
        ps.setString(1, id);
        ps.executeUpdate();
    }
  
}
