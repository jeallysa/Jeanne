/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package beans;

/**
 *
 * @author averey
 */
public class Request {

    private String reqID = "";
    private String firstName = "";
    private String lastName = "";
    private String contact = "";
    private String s_name = "";
    private String category = "";
    private String reqDate = "";
    private String status = "";
    private String price = "";
    
    public Request(String reqID, String firstName, String lastName, String contact, String s_name, String category, String reqDate, String status, String price){
        this.reqID = reqID;
        this.firstName = firstName;
        this.lastName = lastName;
        this.contact = contact;
        this.s_name = s_name;
        this.category = category;
        this.reqDate = reqDate;
        this.status = status;
        this.price = price;
    }
    
    /**
     * @return the price
     */
    public String getPrice() {
        return price;
    }
    /**
     * @return the reqID
     */
    public String getReqID() {
        return reqID;
    }

    /**
     * @return the firstName
     */
    public String getFirstName() {
        return firstName;
    }

    /**
     * @return the lastName
     */
    public String getLastName() {
        return lastName;
    }

    /**
     * @return the contact
     */
    public String getContact() {
        return contact;
    }

    /**
     * @return the s_name
     */
    public String getS_name() {
        return s_name;
    }

    /**
     * @return the category
     */
    public String getCategory() {
        return category;
    }

    /**
     * @return the reqDate
     */
    public String getReqDate() {
        return reqDate;
    }

    /**
     * @return the status
     */
    public String getStatus() {
        return status;
    }
    
}
