/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package beans;

/**
 *
 * @author boni
 */
public class ServiceProvider {

    
    private int spID = 0;
    private int reqID = 0;
    private String username = "";
    private String password = "";
    private String firstName = "";
    private String lastName = "";
    private String contact = "";
    private String email = "";
    private String address = "";
    private String birthdate = "";
    private String service = "";
    private String category = "";
    private String status = "";
    private String reqDate = "";
    
    public ServiceProvider(int spID, int reqID, String username, String password, String firstName, String lastName, String contact, String email, String address, String birthdate, String service, String category, String status){
        this.spID = spID;
        this.reqID = reqID;
        this.username = username;
        this.password = password;
        this.firstName = firstName;
        this.lastName = lastName;
        this.contact = contact;
        this.email = email;
        this.address = address;
        this.birthdate = birthdate;
        this.service = service;
        this.category = category;
        this.status = status;
    }
    
    public ServiceProvider(int spID, int reqID, String username, String password, String firstName, String lastName, String contact, String email, String address, String birthdate, String service, String category, String status, String reqDate){
        this.spID = spID;
        this.reqID = reqID;
        this.username = username;
        this.password = password;
        this.firstName = firstName;
        this.lastName = lastName;
        this.contact = contact;
        this.email = email;
        this.address = address;
        this.birthdate = birthdate;
        this.service = service;
        this.category = category;
        this.status = status;
        this.reqDate = reqDate;
    }

    public String getReqDate() {
        return reqDate;
    }

    public void getSpID() {
        this.spID = spID;
    }
    
    public void getReqID() {
        this.reqID = reqID;
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getContact() {
        return contact;
    }

    public String getEmail() {
        return email;
    }

    public String getAddress() {
        return address;
    }

    public String getBirthdate() {
        return birthdate;
    }
    
    public String getService() {
        return service;
    }

    public String getCategory() {
        return category;
    }
    
    public String getStatus() {
        return status;
    }
}
