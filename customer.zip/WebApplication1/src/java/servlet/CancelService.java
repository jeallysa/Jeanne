/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servlet;

import beans.Database;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author boni
 */
@WebServlet(name = "CancelService", urlPatterns = {"/CancelService"})
public class CancelService extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
  
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String page = request.getParameter("page");
        String reqID = request.getParameter("reqID");
        try {
            Database db = new Database();
            db.cancelService(reqID);
            
            response.sendRedirect(page);
        } catch (SQLException ex) {
            Logger.getLogger(CancelService.class.getName()).log(Level.SEVERE, null, ex);
        }
    }


}
