/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servlet;

import beans.Database;
import beans.Request;
import beans.ServiceProvider;
import com.google.gson.Gson;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Jorgia
 */
public class GetRequest extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        List<Request> requestList = new ArrayList<>();
        try{
            HttpSession session = request.getSession();
            String cuID = session.getAttribute("cuID").toString();
            Database db = new Database();
            ResultSet requests = db.getAllRequest(cuID);
           
            while(requests.next()){
                String reqID = requests.getString("reqID");
                String firstName = requests.getString("FirstName");
                String lastName = requests.getString("LastName");
                String contact = requests.getString("ContactNumber");
                String s_name = requests.getString("s_name");
                String category = requests.getString("s_category");
                String reqDate = requests.getString("reqDate");
                String status = requests.getString("status");
                String price = requests.getString("s_price");
                requestList.add(new Request(reqID, firstName, lastName, contact, s_name, category, reqDate, status, price));
            }
        }catch(Exception e){
            e.printStackTrace();
        }
        
        String json = new Gson().toJson(requestList);
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        response.getWriter().write("{\"data\": "+json+"}");
    }


    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

    }

}
