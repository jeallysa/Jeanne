/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servlet;

import beans.Database;
import beans.Profile;
import com.google.gson.Gson;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author boni
 */
public class GetProfile extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        Profile profile = null;
        try {
            HttpSession session = request.getSession();
            String cuID = session.getAttribute("cuID").toString();
            Database db = new Database();
            ResultSet rs = db.getProfile(cuID);
            while(rs.next())
            {
                int id = rs.getInt("cuID");
                String image = rs.getString("Image");
                String username = rs.getString("UserName");
                String firstName = rs.getString("FirstName");
                String lastName = rs.getString("LastName");
                String contact = rs.getString("ContactNumber");
                String password = rs.getString("Password");
                String email = rs.getString("Email");
                String address = rs.getString("Address");
                String bd_numeric = rs.getString("bd_numeric");
                String bd_string = rs.getString("bd_string");
                profile = new Profile(id, image, firstName, lastName, contact, username, password, email, address, bd_numeric, bd_string);
            }
            
            String json = new Gson().toJson(profile);
            response.setContentType("application/json");
            response.setCharacterEncoding("UTF-8");
            response.getWriter().write(json);
        } catch (SQLException ex) {
            Logger.getLogger(GetProfile.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
       
    }

}
