/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servlet;

import beans.Database;
import beans.Profile;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;

/**
 *
 * @author boni
 */
@MultipartConfig(fileSizeThreshold=1024*1024*1, 
             maxFileSize=1024*1024*100,     
             maxRequestSize=1024*1024*100)
public class EditProfile extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        try {
            HttpSession session = request.getSession();
            String cuID = session.getAttribute("cuID").toString();
            int id = Integer.parseInt(cuID);
            PrintWriter out = response.getWriter();
            Database db = new Database();
            
            String imageName = "c-"+cuID+".png";
            String path = request.getServletContext().getRealPath("/assets/uploads");
            File file = new File(path);
            Part part = request.getPart("image");
            part.write(path + File.separator + imageName);
            
            String firstName = request.getParameter("firstName");
            String lastName = request.getParameter("lastName");
            String contact = request.getParameter("contact");
            String email = request.getParameter("email");
            String address = request.getParameter("address");
            String username = request.getParameter("username");
            String password = request.getParameter("password");
            
            Profile profile = new Profile(id, imageName, firstName, lastName, contact, email, address, username, password);
            db.editProfile(profile);
            
            session.setAttribute("name", firstName+" "+lastName);
            session.setAttribute("image", imageName);
            response.sendRedirect("profile.jsp");
        } catch (SQLException ex) {
            Logger.getLogger(EditProfile.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

}
