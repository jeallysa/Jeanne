/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servlet;

import beans.Database;
import beans.Service;
import beans.ServiceProvider;
import com.google.gson.Gson;
import java.io.*;
import java.sql.*;
import java.util.*;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author boni
 */
public class GetMath extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        List<Service> academics = new ArrayList<>();
        try{
            HttpSession session = request.getSession();
            String cuID = session.getAttribute("cuID").toString();
            Database db = new Database();
            ResultSet service = db.getAllMathRequest(cuID);
           
            while(service.next()){
                String s_id = service.getString("s_id");
                String s_name = service.getString("s_name");
                String s_category = service.getString("s_category");
                String s_price = service.getString("s_price");
                String spID = service.getString("spID");
                String firstName = service.getString("FirstName");
                String lastName = service.getString("LastName");
                String contact = service.getString("ContactNumber");

                academics.add(new Service(s_id, s_name, s_category, s_price, spID, firstName, lastName, contact));
            }
        }catch(Exception e){
            e.printStackTrace();
        }
        
        String json = new Gson().toJson(academics);
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        response.getWriter().write("{\"data\": "+json+"}");
    }


    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

    }

}
