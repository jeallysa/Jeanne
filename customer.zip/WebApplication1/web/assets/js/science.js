$(document).ready(function(){
    var table = $('#table').DataTable({
                    ajax: window.location.origin+'/customer/GetScience',
                    columns: [
                        {data: 's_name'},
                        {data: 's_price'},
                        {
                            mRender: function(row, setting, full){
                                return full.firstName + ' ' + full.lastName;
                            }
                        },
                        {data: 'contact'},
                        {
                            mRender: function(row, setting, full){
                                if(full.status == 'pending'){
                                    return "<button class='btn btn-danger btn-sm cancel'>Cancel</button>";
                                }
                                return "<button class='btn btn-info btn-sm add'>Add</button>";
                            }
                        }
                    ],
                    bPaginate: false,
                    bInfo: false
                });
    
    $('#table').on('click', '.add', function(){
        let data = table.row(this.closest('tr')).data();
        let modal = $('#add');
        $('#service-name').text(data.s_name);
        modal.find('.name').val(data.firstName+' '+data.lastName);
        modal.find('.contact').val(data.contact);
        modal.find('input[name=s_id]').val(data.s_id);
        $('#add').modal('show');
    });
    
    $('#table').on('click', '.cancel', function(){
        let data = table.row(this.closest('tr')).data();
        let modal = $('#cancel');
        modal.find('.title').text(data.service);
        modal.find('input[name=reqID]').val(data.reqID);
        modal.find('input[name=serviceType]').val(data.service);
        $('#cancel').modal('show');
    });
    
    $('#search').on('keyup', function () {
        table.search(this.value).draw();
    });
    
    $.get(window.location.origin+'/customer/GetNotification', function(response){
        let notification_count = response.data.length;
        $('#notif-count').text(notification_count);
        if(notification_count === 0){
            $('#notif-count').css('display', 'none');
        }
    });
});