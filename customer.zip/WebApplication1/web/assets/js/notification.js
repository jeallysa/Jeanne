$(document).ready(function(){
    var table = $('#table').DataTable({
                    ajax: window.location.origin+'/customer/GetNotificationTable',
                    columns: [
                        {data: 's_name'},
                        {data: 'price'},
                        {
                            mRender: function(row, setting, full){
                                return full.firstName + ' ' + full.lastName;
                            }
                        },
                        {data: 'contact'},
                        {data: 'reqDate'},
                        {data: 'status'}
                    ],
                    bPaginate: false,
                    bInfo: false
                });
                
    
    $('#search').on('keyup', function () {
        table.search(this.value).draw();
    });
    var cuID = $('#cuIDVal').val();
        console.log(cuID)
//    $.get(window.location.origin+'/customer/UpdateNotification', function(response){
//        
//        console.log(response);
//    });
});