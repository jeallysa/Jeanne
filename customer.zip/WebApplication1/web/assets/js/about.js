$(document).ready(function(){
    $('#search').css('display', 'none');
    
    $.get(window.location.origin+'/customer/GetNotification', function(response){
        let notification_count = response.data.length;
        $('#notif-count').text(notification_count);
        if(notification_count === 0){
            $('#notif-count').css('display', 'none');
        }
    });
});