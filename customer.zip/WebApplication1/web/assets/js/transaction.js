$(document).ready(function(){
    var table = $('#table').DataTable({
                    ajax: window.location.origin+'/customer/GetTransaction',
                    columns: [
                        {data: 's_name'},
                        {data: 'price'},
                        {
                            mRender: function(row, setting, full){
                                return full.firstName + ' ' + full.lastName;
                            }
                        },
                        {data: 'contact'},
                        {data: 'reqDate'},
                        {data: 'status'}
                    ],
                    bPaginate: false,
                    bInfo: false
                });

    $('#search').on('keyup', function () {
        table.search(this.value).draw();
    });
    
    $.get(window.location.origin+'/customer/GetNotification', function(response){
        let notification_count = response.data.length;
        $('#notif-count').text(notification_count);
        if(notification_count === 0){
            $('#notif-count').css('display', 'none');
        }
    });
});