$(document).ready(function(){
    $.get(window.location.origin+'/customer/GetProfile', function(response){
        let data = response;
        $('#name').text(data.firstName+' '+data.lastName);
        $('#contact').text(data.contact);
        $('#email').text(data.email);
        $('#address').text(data.address);
        $('#username').text(data.username);
        $('#password').text(data.password);
    });
    
    $('#search').css('display', 'none');
    
    $.get(window.location.origin+'/customer/GetNotification', function(response){
        let notification_count = response.data.length;
        $('#notif-count').text(notification_count);
        if(notification_count === 0){
            $('#notif-count').css('display', 'none');
        }
    });
});