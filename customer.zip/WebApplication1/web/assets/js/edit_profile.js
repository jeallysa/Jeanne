$(document).ready(function(){
    $.get(window.location.origin+'/customer/GetProfile', function(response){
        let data = response;
        
        $('.temp-img').attr('src', 'assets/uploads/'+(data.image == "" ? "profile.png" : data.image));
        $('input[name=firstName]').val(data.firstName);
        $('input[name=lastName]').val(data.lastName);
        $('input[name=contact]').val(data.contact);
        $('input[name=email]').val(data.email);
        $('textarea[name=address]').val(data.address);
        $('input[name=username]').val(data.username);
    });
    
    $('#search').css('display', 'none');
    
    $('.img').change(function(ev){
      readURL(this);
    });

    var readURL = function(input){
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            var form = $(input).closest('form');

            reader.onload = function (e) {
               form.find('.temp-img').attr('src', e.target.result);
            }
            reader.readAsDataURL(input.files[0]);
        }
    }
    
    $.get(window.location.origin+'/customer/GetNotification', function(response){
        let notification_count = response.data.length;
        $('#notif-count').text(notification_count);
        if(notification_count === 0){
            $('#notif-count').css('display', 'none');
        }
    });
});